// Place any global data in this file.
// You can import this data from anywhere in your site by using the `import` keyword.

export const SITE_TITLE = 'Shepherd — Guide your users through a tour of your app.';
export const SITE_DESCRIPTION = 'Guide your users through a tour of your app.';
