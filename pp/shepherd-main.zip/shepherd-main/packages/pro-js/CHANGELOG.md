# @shepherdpro/pro-js

## 0.0.3

### Patch Changes

- Fix exports for published packages

## 0.0.2

### Patch Changes

- Improve types and reusing the Pro JS module
